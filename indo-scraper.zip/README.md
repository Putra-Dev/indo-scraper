# indo-scraper

Scraper Indonesia berbasis Node.js. Mengambil data dari berbagai sumber publik tanpa API key.

## Instalasi

```bash
npm install indo-scraper
```

## Cara Pakai

```js
const Scraper = require('indo-scraper')
const s = new Scraper()

const result = await s.kompas({ channel: 'news', limit: 5 })
console.log(result)
```

## Format Response

Semua method mengembalikan format yang sama:

**Sukses:**
```json
{
  "creator": "Angga Putra",
  "status": true,
  "data": { } 
}
```

**Gagal:**
```json
{
  "creator": "Angga Putra",
  "status": false,
  "msg": "pesan error"
}
```

> `data` bisa berupa `{}` object atau `[]` array tergantung method.

---

## Struktur Folder

```
indo-scraper/
├── index.js              ← class Scraper, entry point
├── src/
│   ├── utils.js          ← helpers: fetchHTML, fetchJSON, ok, fail, dll
│   ├── news/             ← scraper berita
│   │   ├── kompas.js
│   │   ├── detik.js
│   │   ├── cnn.js
│   │   ├── tribun.js
│   │   ├── liputan6.js
│   │   ├── okezone.js
│   │   ├── antara.js
│   │   └── republika.js
│   ├── bmkg/             ← scraper BMKG
│   │   ├── gempa.js
│   │   └── cuaca.js
│   ├── finance/          ← scraper keuangan
│   │   ├── saham.js
│   │   ├── kurs.js
│   │   ├── emas.js
│   │   └── bbm.js
│   └── info/             ← tools informasi
│       ├── cekno.js
│       └── resi.js
```

---

## Daftar Method

### Berita

#### `s.kompas(options)`
Berita terbaru dari Kompas.com. Sumber: `indeks.kompas.com`
```js
await s.kompas({ channel: 'news', page: 1, limit: 20, date: '11/05/2026' })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'news'` | `news` `regional` `megapolitan` `money` `sport` `tekno` `sains` `travel` `food` `health` |
| page | `1` | angka |
| limit | `20` | angka |
| date | `null` | format `dd/mm/yyyy` |

#### `s.kompasArticle(url)`
Isi artikel lengkap Kompas.
```js
await s.kompasArticle('https://nasional.kompas.com/read/...')
```

---

#### `s.detik(options)`
Berita terbaru dari Detik.com. Sumber: `*.detik.com/indeks`
```js
await s.detik({ channel: 'news', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'news'` | `news` `finance` `hot` `sport` `inet` `oto` `health` `travel` `food` |

#### `s.detikSearch(query, limit)`
Cari berita di Detik.
```js
await s.detikSearch('pemilu', 10)
```

#### `s.detikArticle(url)`
Isi artikel lengkap Detik.

---

#### `s.cnn(options)`
Berita terbaru dari CNN Indonesia. Sumber: `cnnindonesia.com`
```js
await s.cnn({ category: 'nasional', limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| category | `'nasional'` | `nasional` `internasional` `ekonomi` `olahraga` `teknologi` `hiburan` `gaya_hidup` |

#### `s.cnnArticle(url)`
Isi artikel lengkap CNN Indonesia.

---

#### `s.tribun(options)`
Berita terbaru dari Tribunnews. Sumber: `tribunnews.com`
```js
await s.tribun({ channel: 'nasional', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'nasional'` | `nasional` `regional` `internasional` `sport` `bisnis` `seleb` `lifestyle` `techno` `otomotif` |

#### `s.tribunArticle(url)`
Isi artikel lengkap Tribunnews.

---

#### `s.liputan6(options)`
Berita terbaru dari Liputan6. Sumber: `liputan6.com`
```js
await s.liputan6({ channel: 'news', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'news'` | `news` `bisnis` `bola` `tekno` `showbiz` `otomotif` `health` `lifestyle` `global` |

#### `s.liputan6Article(url)`
Isi artikel lengkap Liputan6.

---

#### `s.okezone(options)`
Berita terbaru dari Okezone. Sumber: `*.okezone.com/indeks`
```js
await s.okezone({ channel: 'nasional', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'nasional'` | `nasional` `economy` `sports` `techno` `celebrity` `lifestyle` `otomotif` `health` |

#### `s.okenewsArticle(url)`
Isi artikel lengkap Okezone.

---

#### `s.antara(options)`
Berita terbaru dari Antara News. Sumber: `antaranews.com`
```js
await s.antara({ channel: 'nasional', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'nasional'` | `nasional` `hukum` `ekonomi` `olahraga` `hiburan` `internasional` `tekno` `otomotif` |

#### `s.antaraArticle(url)`
Isi artikel lengkap Antara News.

---

#### `s.republika(options)`
Berita terbaru dari Republika. Sumber: `republika.co.id`
```js
await s.republika({ channel: 'nasional', page: 1, limit: 20 })
```
| Opsi | Default | Pilihan |
|------|---------|---------|
| channel | `'nasional'` | `nasional` `internasional` `ekonomi` `olahraga` `hiburan` `tekno` `gaya_hidup` |

#### `s.republikaArticle(url)`
Isi artikel lengkap Republika.

---

### BMKG

#### `s.bmkgGempa()`
Gempa bumi terbaru (1 data). Sumber: `bmkg-content-inatews.storage.googleapis.com`
```js
await s.bmkgGempa()
```
**Output:** `tanggal` `jam` `datetime` `koordinat` `lintang` `bujur` `magnitude` `kedalaman` `wilayah` `potensi` `dirasakan` `shakemap`

#### `s.bmkgGempaTerkini()`
15 gempa bumi terkini.
```js
await s.bmkgGempaTerkini()
```

#### `s.bmkgGempaDirasakan()`
Gempa bumi yang dirasakan masyarakat.
```js
await s.bmkgGempaDirasakan()
```

#### `s.bmkgCuaca(kota)`
Prakiraan cuaca kota. Sumber: `api.bmkg.go.id`
```js
await s.bmkgCuaca('jakarta')
```
| Pilihan kota |
|---|
| `jakarta` `bandung` `surabaya` `medan` `semarang` `makassar` `yogyakarta` `palembang` `denpasar` `balikpapan` |

**Output:** `lokasi` (kecamatan, kotkab, provinsi) + `prakiraan` (datetime, cuaca, suhu, suhu_min, suhu_max, kelembaban, angin, arah_angin, icon)

---

### Finance

#### `s.saham(kode)`
Harga saham atau IHSG. Sumber: `TradingView`
```js
await s.saham('ihsg')
await s.saham('bbca')
await s.saham('GOTO') // kode IDX langsung
```
Kode bawaan: `ihsg` `bbca` `bbri` `bmri` `tlkm` `asii` `goto` `unvr` `hmsp` `antm` `indf` `klbf`

**Output:** `kode` `nama` `close` `open` `high` `low` `volume` `perubahan_pct` `perubahan_abs` + `performa` (1W, 1M, 3M, 6M, 1Y, YTD)

> IHSG output: `kode` `symbol` `open` `high` `low` `close` `volume` `update`

#### `s.sahamList(limit)`
Daftar semua saham Indonesia diurutkan by market cap. Sumber: `TradingView Scanner`
```js
await s.sahamList(50)  // default 50, max 906
```

---

#### `s.kurs(kode)`
Kurs mata uang ke IDR. Sumber: `fiskal.kemenkeu.go.id`
```js
await s.kurs('usd')
```
Kode: `usd` `eur` `gbp` `jpy` `sgd` `myr` `aud` `cny` `sar` + semua kode ISO 4217

**Output:** `mata_uang` `kode` `nilai` `perubahan` `sumber`

#### `s.kursAll()`
Semua kurs dari Kemenkeu sekaligus.
```js
await s.kursAll()
```

---

#### `s.emasAntam()`
Harga emas Antam per gram. Sumber: `logammulia.com`
```js
await s.emasAntam()
```
**Output:** `tanggal` + `data` (berat, harga_dasar, harga_termasuk_pajak)

#### `s.emasHarga()`
Harga emas dunia (Ounce & Gram dalam IDR). Sumber: `harga-emas.org`
```js
await s.emasHarga()
```

---

#### `s.bbm()`
Harga BBM Pertamina terkini. Sumber: `pertamina.com`
```js
await s.bbm()
```

---

### Info

#### `s.cekNomor(nomor)`
Cek provider dan info nomor HP Indonesia. Tanpa network request.
```js
await s.cekNomor('08123456789')
await s.cekNomor('+628123456789')
await s.cekNomor('628123456789')
```
**Output:** `nomor_asli` `nomor` `prefix` `provider` `panjang`

Provider yang dikenali: `Telkomsel` `Indosat` `XL` `AXIS` `Smartfren` `Three`

#### `s.cekResi(kurir, noResi)`
Cek status resi pengiriman. Sumber: `cekresi.com`
```js
await s.cekResi('jne', 'RESI123456')
await s.cekResi('sicepat', 'RESI789')
```
Kurir: `jne` `jnt` `j&t` `sicepat` `pos` `anteraja` `wahana` `tiki` `ninja` `lion`

**Output:** `kurir` `noResi` `status` + `history` (tanggal, keterangan, lokasi)

---

## Cara Menambah Scraper Baru

1. Buat file baru di folder yang sesuai, contoh `src/news/bisnis.js`
2. Import helper dari utils:
```js
const { fetchHTML, cheerio, parseLdJson, parseThumbnail, parseParagraphs, ok, fail } = require('../utils')
```
3. Tulis method sebagai arrow function:
```js
/*
 * Berita terbaru Bisnis Indonesia
 * @param {object} options
 */
const bisnis = async (options = {}) => {
  return new Promise(async (resolve) => {
    try {
      // logic scraping
      resolve(ok(data))
    } catch (e) { console.log(e); resolve(fail(e)) }
  })
}

module.exports = { bisnis }
```
4. Daftarkan di `index.js`:
```js
require('./src/news/bisnis'),
```

---

## Catatan

- Beberapa scraper news (liputan6, okezone, antara, republika) mungkin perlu update selector jika situs mengubah struktur HTML. Gunakan script debug untuk inspect HTML.
- Selector CSS bergantung pada struktur HTML situs. Jika `status: false` dengan pesan "Data tidak ditemukan", kemungkinan selector perlu disesuaikan.
- BMKG Gempa menggunakan mirror Google Storage, bukan endpoint utama BMKG yang sering rate-limit.
- Saham & IHSG menggunakan TradingView Scanner (tanpa API key, tanpa rate limit).
- Kurs menggunakan Kemenkeu (pemerintah, tanpa rate limit).
